package kr.co.korearental.petproto;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class AlarmActivity extends AppCompatActivity {

    private AlarmManager alarmManager;
    private GregorianCalendar mCalender;

    private NotificationManager notificationManager;
    NotificationCompat.Builder builder;

    private Button btn_alarm_on;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        mCalender = new GregorianCalendar();
        Log.v("HelloAlarmActivity", mCalender.getTime().toString());
        setContentView(R.layout.activity_alarm);

        final Intent mainIntent = new Intent(AlarmActivity.this, MainActivity.class);

        final RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup1);
        radioGroup.clearCheck();

        final CheckBox ck1_1 = (CheckBox)findViewById(R.id.checkBox_alarm_walk);
        final CheckBox ck1_2 = (CheckBox)findViewById(R.id.checkBox_alarm_walk2);
        final CheckBox ck1_3 = (CheckBox)findViewById(R.id.checkBox_alarm_walk3);
        final CheckBox ck1_4 = (CheckBox)findViewById(R.id.checkBox_alarm_walk4);
        //////
        final CheckBox ck2_1 = (CheckBox)findViewById(R.id.checkBox_alarm_eat);
        final CheckBox ck2_2 = (CheckBox)findViewById(R.id.checkBox_alarm_eat2);
        final CheckBox ck2_3 = (CheckBox)findViewById(R.id.checkBox_alarm_eat3);
        ///////
        final CheckBox ck3_1 = (CheckBox)findViewById(R.id.checkBox_alarm_brush);
        final CheckBox ck3_2 = (CheckBox)findViewById(R.id.checkBox_alarm_brush2);
        final CheckBox ck3_3 = (CheckBox)findViewById(R.id.checkBox_alarm_brush3);
        ///////
        final CheckBox ck4_1 = (CheckBox)findViewById(R.id.checkBox_alarm_fur);
        final CheckBox ck4_2 = (CheckBox)findViewById(R.id.checkBox_alarm_fur2);
        final CheckBox ck4_3 = (CheckBox)findViewById(R.id.checkBox_alarm_fur3);
        final CheckBox ck4_4 = (CheckBox)findViewById(R.id.checkBox_alarm_fur4);

        btn_alarm_on = (Button) findViewById(R.id.button_alarm_on);
        btn_alarm_on.setOnClickListener(new View.OnClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                int rb = ((RadioGroup) radioGroup.findViewById(R.id.radioGroup1)).getCheckedRadioButtonId();

                switch(rb){
                    case R.id.radio_alarm_on:{
                        if(ck1_1.isChecked())
                        {
                            setAlarm1_1();
                        }
                        if(ck1_2.isChecked())
                        {
                            setAlarm1_2();
                        }
                        if(ck1_3.isChecked())
                        {
                            setAlarm1_3();
                        }
                        if(ck1_4.isChecked())
                        {
                            setAlarm1_4();
                        }
                        /////////
                        if(ck2_1.isChecked())
                        {
                            setAlarm2_1();
                        }
                        if(ck2_2.isChecked())
                        {
                            setAlarm2_2();
                        }
                        if(ck2_3.isChecked())
                        {
                            setAlarm2_3();
                        }
                        ////////
                        if(ck3_1.isChecked())
                        {
                            setAlarm3_1();
                        }
                        if(ck3_2.isChecked())
                        {
                            setAlarm3_2();
                        }
                        if(ck3_3.isChecked())
                        {
                            setAlarm3_3();
                        }
                        ////////
                        if(ck4_1.isChecked())
                        {
                            setAlarm4_1();
                        }
                        if(ck4_2.isChecked())
                        {
                            setAlarm4_2();
                        }
                        if(ck4_3.isChecked())
                        {
                            setAlarm4_3();
                        }
                        if(ck4_4.isChecked())
                        {
                            setAlarm4_4();
                        }
                        startActivity(mainIntent);
                        break;
                    }
                    case R.id.radio_alarm_off:{
                        String id1_1 = "walk1";
                        notificationManager.deleteNotificationChannel(id1_1);
                        String id1_2 = "walk2";
                        notificationManager.deleteNotificationChannel(id1_2);
                        String id1_3 = "walk3";
                        notificationManager.deleteNotificationChannel(id1_3);
                        String id1_4 = "walk4";
                        notificationManager.deleteNotificationChannel(id1_4);
                        /////////
                        String id2_1 = "eat1";
                        notificationManager.deleteNotificationChannel(id2_1);
                        String id2_2 = "eat2";
                        notificationManager.deleteNotificationChannel(id2_2);
                        String id2_3 = "eat3";
                        notificationManager.deleteNotificationChannel(id2_3);
                        /////////
                        String id3_1 = "brush1";
                        notificationManager.deleteNotificationChannel(id3_1);
                        String id3_2 = "brush2";
                        notificationManager.deleteNotificationChannel(id3_2);
                        String id3_3 = "brush3";
                        notificationManager.deleteNotificationChannel(id3_3);
                        //////////
                        String id4_1 = "fur1";
                        notificationManager.deleteNotificationChannel(id4_1);
                        String id4_2 = "fur2";
                        notificationManager.deleteNotificationChannel(id4_2);
                        String id4_3 = "fur3";
                        notificationManager.deleteNotificationChannel(id4_3);
                        String id4_4 = "fur4";
                        notificationManager.deleteNotificationChannel(id4_4);
                        ///////////
                        startActivity(mainIntent);
                        break;
                    }
                }
            }
        });

    }

    //알림 기능
    private void setAlarm1_1() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier1_1.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,8);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm1_2() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier1_2.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,13);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm1_3() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier1_3.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,19);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm1_4() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier1_4.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,23);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    /////////////////////
    private void setAlarm2_1() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier2_1.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,7);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm2_2() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier2_2.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,12);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm2_3() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier2_3.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,18);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    ///////////////
    private void setAlarm3_1() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier3_1.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,8);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm3_2() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier3_2.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,13);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm3_3() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier3_3.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,19);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    //////////////////
    private void setAlarm4_1() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier4_1.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,9);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm4_2() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier4_2.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,14);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm4_3() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier4_3.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,20);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    private void setAlarm4_4() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier4_4.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,24);
        calendar.set(Calendar.MINUTE,00);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }

/*
    //알림 기능
    private void setAlarm() {

        //AlarmReceiver에 값 전달
        Intent receiverIntent = new Intent(AlarmActivity.this, AlarmRecevier.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AlarmActivity.this, 0, receiverIntent, 0);

        //String from = "21:47:30"; //임의로 날짜와 시간을 지정

        //날짜 포맷을 바꿔주는 소스코드
        //SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
//        Date datetime = null;
//        try {
//            datetime = dateFormat.parse(from);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY,18);
        calendar.set(Calendar.MINUTE,10);
        calendar.set(Calendar.SECOND,00);

        alarmManager.setRepeating(AlarmManager.RTC, calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
    */
}
